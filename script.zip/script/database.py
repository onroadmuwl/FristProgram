# -*- coding: UTF-8 -*-
import wx
import wx.grid
import pymysql
from script import ADD_it
from script import  DELETE
db = pymysql.connect(host="127.0.0.1", user="muwenlong", passwd="12345678", db="学生数据管理系统",charset='utf8' )

# 使用cursor()方法获取操作游标
'''cursor = db.cursor()
sql='SELECT * FROM 学生基本信息表'
cursor.execute(sql)
results = cursor.fetchall()
#print results'''
global results


def search(event):
    value_name=Ctrl_1.GetValue()
    #print("qq"+value_name)
    cursor = db.cursor()
    string = str(value_name)
    sql = "SELECT * FROM 学生基本信息表 \
               WHERE 姓名='{0}'".format(string)
    cursor.execute(sql)
    global results
    results = cursor.fetchall()
    result=str(results)
    #print("输出" + str(results))


    if result=="()":
        MESSAGE()
    else:

        app = wx.App()

        frame = wx.Frame(None, -1, string,
                         size=(520, 150))
        grid = wx.grid.Grid(frame)
        tableBase = GenericTable(wx.grid.GridTableBase)
        grid.SetTable(tableBase, True)
        frame.Show(True)
        frame.Center()
        app.MainLoop()
def search_1(event):
    value_number = Ctrl_2.GetValue()
    cursor = db.cursor()
    string = str(value_number)
    sql = "SELECT * FROM 学生基本信息表 \
                   WHERE 学号='{0}'".format(string)
    cursor.execute(sql)
    global results
    results = cursor.fetchall()

    result = str(results)
    # print("输出" + str(results))

    if result == "()":
        MESSAGE()
    else:

        app = wx.App()

        frame = wx.Frame(None, -1, string,
                         size=(520, 150))
        grid = wx.grid.Grid(frame)
        tableBase = GenericTable(wx.grid.GridTableBase)
        grid.SetTable(tableBase, True)
        frame.Show(True)
        frame.Center()
        app.MainLoop()


def data_men(event):
    cursor = db.cursor()
    string = "男"
    sql = "SELECT * FROM 学生基本信息表 \
           WHERE 性别='{0}'".format(string)
    cursor.execute(sql)
    global results
    results = cursor.fetchall()



def data_women(event):
    cursor = db.cursor()
    string = "女"
    sql = "SELECT * FROM 学生基本信息表 \
           WHERE 性别='{0}'".format(string)
    cursor.execute(sql)
    global results
    results = cursor.fetchall()

def data_dianzi(event):
    cursor = db.cursor()
    string = "电子商务"
    sql = "SELECT * FROM 学生基本信息表 \
           WHERE 专业='{0}'".format(string)
    cursor.execute(sql)
    global results
    results = cursor.fetchall()


def data_caiguan(event):
    cursor = db.cursor()
    string = "财务管理"
    sql = "SELECT * FROM 学生基本信息表 \
           WHERE 专业='{0}'".format(string)
    cursor.execute(sql)
    global results
    results = cursor.fetchall()



def data_gongshang(event):
    cursor = db.cursor()
    string = "工商管理"
    sql = "SELECT * FROM 学生基本信息表 \
           WHERE 专业='{0}'".format(string)
    cursor.execute(sql)
    global results
    results = cursor.fetchall()




def data_renli(event):
    cursor = db.cursor()
    string = "人力资源管理"
    sql = "SELECT * FROM 学生基本信息表 \
           WHERE 专业='{0}'".format(string)
    cursor.execute(sql)
    global results
    results = cursor.fetchall()


def data_wuliu(event):
    cursor = db.cursor()
    string = "物流管理"
    sql = "SELECT * FROM 学生基本信息表 \
           WHERE 专业='{0}'".format(string)
    cursor.execute(sql)
    global results
    results = cursor.fetchall()


def data_lvyou(event):
    cursor = db.cursor()
    string = "旅游管理"
    sql = "SELECT * FROM 学生基本信息表 \
           WHERE 专业='{0}'".format(string)
    cursor.execute(sql)
    global results
    results = cursor.fetchall()




def data_all(event):
    cursor = db.cursor()
    sql = 'SELECT * FROM 学生基本信息表'
    cursor.execute(sql)
    global results
    results = cursor.fetchall()
    # print results





def f():
    app = wx.App()

    frame = wx.Frame(None, -1, "17级商旅学院学生基本信息表",
                     size=(520, 500))
    grid = wx.grid.Grid(frame)
    tableBase = GenericTable(wx.grid.GridTableBase)
    grid.SetTable(tableBase, True)
    frame.Show(True)
    frame.Center()
    app.MainLoop()

def f_1():
    app = wx.App()

    frame = wx.Frame(None, -1, "17级商旅学院电子商务学生基本信息表",
                     size=(520, 500))
    grid = wx.grid.Grid(frame)
    tableBase = GenericTable(wx.grid.GridTableBase)
    grid.SetTable(tableBase, True)
    frame.Show(True)
    frame.Center()
    app.MainLoop()

def f_2():
    app = wx.App()

    frame = wx.Frame(None, -1, "17级商旅学院财务管理学生基本信息表",
                     size=(520, 500))
    grid = wx.grid.Grid(frame)
    tableBase = GenericTable(wx.grid.GridTableBase)
    grid.SetTable(tableBase, True)
    frame.Show(True)
    frame.Center()
    app.MainLoop()


def f_3():
    app = wx.App()

    frame = wx.Frame(None, -1, "17级商旅学院工商管理学生基本信息表",
                     size=(520, 500))
    grid = wx.grid.Grid(frame)
    tableBase = GenericTable(wx.grid.GridTableBase)
    grid.SetTable(tableBase, True)
    frame.Show(True)
    frame.Center()
    app.MainLoop()


def f_4():
    app = wx.App()

    frame = wx.Frame(None, -1, "17级商旅学院人力资源管理学生基本信息表",
                     size=(520, 500))
    grid = wx.grid.Grid(frame)
    tableBase = GenericTable(wx.grid.GridTableBase)
    grid.SetTable(tableBase, True)
    frame.Show(True)
    frame.Center()
    app.MainLoop()


def f_5():
    app = wx.App()

    frame = wx.Frame(None, -1, "17级商旅学院物流管理学生基本信息表",
                     size=(520, 500))
    grid = wx.grid.Grid(frame)
    tableBase = GenericTable(wx.grid.GridTableBase)
    grid.SetTable(tableBase, True)
    frame.Show(True)
    frame.Center()
    app.MainLoop()

def f_6():
    app = wx.App()

    frame = wx.Frame(None, -1, "17级商旅学院旅游管理学生基本信息表",
                     size=(520, 500))
    grid = wx.grid.Grid(frame)
    tableBase = GenericTable(wx.grid.GridTableBase)
    grid.SetTable(tableBase, True)
    frame.Show(True)
    frame.Center()
    app.MainLoop()


def table_all(event):
    data_all(event=True)
    f()

def f_7():
    app = wx.App()

    frame = wx.Frame(None, -1, "性别男",
                     size=(520, 500))
    grid = wx.grid.Grid(frame)
    tableBase = GenericTable(wx.grid.GridTableBase)
    grid.SetTable(tableBase, True)
    frame.Show(True)
    frame.Center()
    app.MainLoop()

def f_8():
    app = wx.App()

    frame = wx.Frame(None, -1, "性别女",
                     size=(520, 500))
    grid = wx.grid.Grid(frame)
    tableBase = GenericTable(wx.grid.GridTableBase)
    grid.SetTable(tableBase, True)
    frame.Show(True)
    frame.Center()
    app.MainLoop()



def gui():
    app = wx.App()
    FRAME=wx.Frame(None,-1,title="学生基本信息表",size=(480,450))
    mypanel=wx.Panel(FRAME,-1)
    h=wx.BoxSizer(wx.HORIZONTAL)
    BUTTON_1=wx.Button(mypanel,-1,label="查看完整表",size=(150,40),pos=(10,70))
    BUTTON_1.Bind(wx.EVT_BUTTON,table_all)

    BUTTON_2=wx.Button(mypanel,-1,label="退出",size=(80,40),pos=(350,70))
    BUTTON_2.Bind(wx.EVT_BUTTON,q)


    statictext=wx.StaticText(mypanel,-1,label="表中操作",pos=(20,10))
    font=wx.Font(pointSize=20,family=wx.DECORATIVE,style=wx.NORMAL,weight=wx.BOLD)
    statictext.SetFont(font)
    lists1=['财务管理','电子商务','人力资源管理','旅游管理','物流管理','工商管理']
    list2 = ['男', '女']
    statictext_1 = wx.StaticText(mypanel, -1, label="__"*1000, pos=(5,120))
    statictext_2 = wx.StaticText(mypanel, -1, label="按专业查询" , pos=(5, 300),style=wx.CB_SORT)
    CH=wx.ComboBox(mypanel,-1,value='请选择',choices=lists1,size=(150,30),pos=(100,295))
    #BUTTON_3=wx.Button(mypanel,-1,label="确定",size=(60,30),pos=(350,295))
    global word
    CH.Bind(wx.EVT_COMBOBOX,chocie)
    #BUTTON_3.Bind(wx.EVT_BUTTON,a)
    #CH.Bind(wx.EVT_COMBOBOX,a)





    statictext_3 = wx.StaticText(mypanel, -1, label="按性别查询" , pos=(5, 250))
    CH_2=wx.ComboBox(mypanel,-1,value='请选择',choices=list2,size=(150,30),pos=(100,245))
    #BUTTON_4 = wx.Button(mypanel, -1, label="确定", size=(60, 30), pos=(350, 245))
    CH_2.Bind(wx.EVT_COMBOBOX,chocie_1)



    statictext_4 = wx.StaticText(mypanel, -1, label="按姓名查询" , pos=(5, 200))
    global Ctrl_1
    Ctrl_1=wx.TextCtrl(mypanel,-1,value="请输入姓名",size=(150,30),pos=(100,195))
    BUTTON_5 = wx.Button(mypanel, -1, label="确定", size=(60, 30), pos=(350, 195))
    BUTTON_5.Bind(wx.EVT_BUTTON,search)


    statictext_4 = wx.StaticText(mypanel, -1, label="按学号查询", pos=(5, 150))
    global Ctrl_2
    Ctrl_2 = wx.TextCtrl(mypanel, -1, value="请输入学号", size=(150, 30), pos=(100, 145))
    BUTTON_6 = wx.Button(mypanel, -1, label="确定", size=(60, 30), pos=(350, 145))
    BUTTON_6.Bind(wx.EVT_BUTTON, search_1)



    but1=wx.Button(mypanel,-1,label="添加信息",size=(120,40),pos=(20,350))
    but3 = wx.Button(mypanel, -1, label="删除信息", size=(120, 40), pos=(300, 350))
    but1.Bind(wx.EVT_BUTTON,add)
    but3.Bind(wx.EVT_BUTTON,DELETE_1)

    #BUTTON_1.Bind(wx.EVT_BUTTON,look)
    FRAME.Show()
    FRAME.Center()
    app.MainLoop()


def DELETE_1(event):
    DELETE.frame()


def q(event):
    quit(gui)


def add(event):
    ADD_it.FRAME()



class GenericTable(wx.grid.GridTableBase):




    def __init__(self, data, rowLabels=None, colLabels=None):
        wx.grid.GridTableBase.__init__(self)

        data = results
        self.data = data
        colLabels = ("序号", "学号","姓名","性别","专业")
        rowLabels = None

        self.rowLabels = rowLabels
        self.colLabels = colLabels

    def GetNumberRows(self):
        return len(self.data)     #表格列数定义过多会出现闪退

    def GetNumberCols(self):
        return len(self.data[0])

    def GetColLabelValue(self, col):
        if self.colLabels:
            return self.colLabels[col]

    #def GetRowLabelValue(self, row):
       # if self.rowLabels:
        #    return self.rowLabels[row]

    def IsEmptyCell(self, row, col):
        return False

    def GetValue(self, row, col):
        return self.data[row][col]

    #def SetValue(self, row, col, value):
     #   pass





def chocie(event):
    w = format(event.GetString())
    if w=="电子商务":
        data_dianzi(event=True)
        f_1()
    elif w=="财务管理":
        data_caiguan(event=True)
        f_2()
    elif w=="工商管理":
        data_gongshang(event=True)
        f_3()
    elif w=="人力资源管理":
        data_renli(event=True)
        f_4()
    elif w=="物流管理":
        data_wuliu(event=True)
        f_5()
    elif w=="旅游管理":
        data_lvyou(event=True)
        f_6()

def chocie_1(event):
    ww= format(event.GetString())
    if ww=="男":
        data_men(event=True)
        f_8()
    else:
        data_women(event=True)
        f_7()

def MESSAGE():
    dlg = wx.MessageDialog(None, '输入学号（姓名）不存在，请重新输入！','错误'
                       , wx.OK | wx.STAY_ON_TOP)
    result = dlg.ShowModal()
    dlg.Destroy()
    return True



'''
gui()
'''
