import wx
import pymysql
def FRAME():
    app=wx.App()
    frame=wx.Frame(None,-1,title="添加学生信息",size=(350,200))
    mypanel = wx.Panel(frame)
    sta = wx.StaticText(mypanel, -1, label="序号：", pos=(10, 20))
    sta = wx.StaticText(mypanel, -1, label="学号：", pos=(10, 50))
    sta = wx.StaticText(mypanel, -1, label="姓名：", pos=(10, 80))
    sta = wx.StaticText(mypanel, -1, label="性别：", pos=(170, 20))
    sta = wx.StaticText(mypanel, -1, label="专业：", pos=(170, 50))
    global ctrl
    global ctrl_1
    global ctrl_2
    global ctrl_3
    global ctrl_4
    ctrl = wx.TextCtrl(mypanel, -1, size=(100, 20), pos=(50, 20))
    ctrl_1 = wx.TextCtrl(mypanel, -1, size=(100, 20), pos=(50, 45))
    ctrl_2 = wx.TextCtrl(mypanel, -1, size=(100, 20), pos=(50, 75))
    ctrl_3 = wx.TextCtrl(mypanel, -1, size=(100, 20), pos=(210, 20))
    ctrl_4 = wx.TextCtrl(mypanel, -1, size=(100, 20), pos=(210, 45))
    btn = wx.Button(mypanel, -1, label="确定", size=(50, 25), pos=(150, 120))
    btn.Bind(wx.EVT_BUTTON, add)
    frame.Show()
    frame.Center()
    app.MainLoop()
def add(event):
    try:
        conn = pymysql.connect(host="127.0.0.1", port=3306, user="muwenlong", passwd="12345678", db="学生数据管理系统",
                               charset="utf8")
        cus1 = conn.cursor()
        sql = "insert into 学生基本信息表(序号,学号,姓名,性别,专业) values(%s,%s,%s,%s,%s)"
        tx = ctrl.GetValue()
        tx_1 = ctrl_1.GetValue()
        tx_2 = ctrl_2.GetValue()
        tx_3 = ctrl_3.GetValue()
        tx_4 = ctrl_4.GetValue()
        res = [tx, tx_1, tx_2, tx_3, tx_4]
        print(res)
        cus1.execute(sql, res)
        conn.commit()
        cus1.close()
        conn.close()


    except Exception as e:
        dlg = wx.MessageDialog(None, "添加出错，请重试！", "WRONG", wx.OK | wx.ICON_ERROR)
        dlg.ShowModal()
        dlg.Destroy()

    else:
        dlg = wx.MessageDialog(None, "添加成功！", "right", wx.OK | wx.ICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()
        ctrl.SetValue("")
        ctrl_1.SetValue("")
        ctrl_2.SetValue("")
        ctrl_3.SetValue("")
        ctrl_4.SetValue("")

