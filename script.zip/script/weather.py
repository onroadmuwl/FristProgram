#encoding:utf-8--
import urllib.request
import gzip
import json
import wx
global ctrl
def mian():
    a = wx.App()
    FRAME=wx.Frame(None,id=1,title="天气预报",size=(360,240))
    mypanel=wx.Panel(FRAME,id=2)
    text=wx.StaticText(mypanel,id=3,label="请输入查询城市：",pos=(20,70))
    font_1 = wx.Font(15, wx.SCRIPT, wx.NORMAL, wx.NORMAL)
    font_2 = wx.Font(15, wx.SCRIPT, wx.NORMAL, wx.BOLD)
    text.SetFont(font_1)
    global ctrl
    ctrl=wx.TextCtrl(mypanel,id=5,size=(120,30),pos=(180,65))
    #ctrl.SetFont(font_2)

    Button=wx.Button(mypanel,id=11,size=(70,40),pos=(260,150),label="确认")
    Button.SetFont(font_2)
    Button.Bind(wx.EVT_BUTTON,get)
    Button_1= wx.Button(mypanel, id=10, size=(70, 40), pos=(30, 150), label="退出")
    Button_1.SetFont(font_2)
    Button_1.Bind(wx.EVT_BUTTON,quit)
    FRAME.Show()
    FRAME.Center()
    a.MainLoop()



def get_weather_data():  # 获取网站数据
    def show_message(word="",caption=""):
        dlg = wx.MessageDialog(None, word, caption, wx.YES_NO | wx.ICON_INFORMATION)
        if dlg.ShowModal() == wx.ID_YES:
            #self.Close(True)
            pass
        dlg.Destroy()
    city_name =ctrl.GetValue()  # 获取输入框的内容
    url1 = 'http://wthrcdn.etouch.cn/weather_mini?city=' + urllib.parse.quote(city_name)
    url2 = 'http://wthrcdn.etouch.cn/weather_mini?citykey=101010100'
    # 网址1只需要输入城市名，网址2需要输入城市代码
    # print(url1)
    weather_data = urllib.request.urlopen(url1).read()
    # 读取网页数据
    weather_data = gzip.decompress(weather_data).decode('utf-8')
    # 解压网页数据
    weather_dict = json.loads(weather_data)
    # 将json数据转换为dict数据
    if weather_dict.get('desc') == 'invilad-citykey':
        show_message(word='城市不存在',caption='错误')
    else:
        # print(messagebox.askokcancel('xing','bingguo'))
        show_data(weather_dict, city_name)


def get(event):
    get_weather_data()








def show_data(weather_dict, city_name):  # 显示数据
        forecast = weather_dict.get('data').get('forecast')  # 获取数据块
        aa = wx.App()
        name = city_name + '天气情况'
        FRAME_1 = wx.Frame(None, id=111, size=(660, 300), title=name)
        mypanel_1=wx.Panel(FRAME_1,id=44)
        CTRL=wx.TextCtrl(mypanel_1,id=1,size=(3,2),pos=(50,15),style=wx.TE_MULTILINE)
        BUTTON=wx.Button(mypanel_1,id=99,label="退出主程序",size=(100,40),pos=(520,20))
        BUTTON.Bind(wx.EVT_BUTTON,quit)
        for i in range(5):  # 将每一天的数据放入列表中
            LANGS = [(forecast[i].get('date'), '日期'),
                     (forecast[i].get('fengxiang'), '风向'),
                     (str(forecast[i].get('fengji')), '风级'),
                     (forecast[i].get('high'), '最高温'),
                     (forecast[i].get('low'), '最低温'),
                     (forecast[i].get('type'), '天气')]

            #group = wx.RadioBox(mypanel_1,label='天气状况',pos=(0,20))  # 框架
            #group.pack  # 放置框架
            for lang, value in LANGS:  # 将数据放入框架中
                c = str(value + ': ' + lang)
                #str_1=str("\n"+c)
                CTRL.AppendText(c)
                CTRL.AppendText('\n')
                #print(str_1)
            #print("###########")

            #q="------------------------------------------------------"
            i_1 = str(i)
            fujia = str("第" + i_1 + "天后天气情况")
            CTRL.AppendText('\n')
            CTRL.AppendText('\n')
            CTRL.AppendText(fujia)
            aaj=CTRL.GetValue()
            data=i*125+20
            aaaaa=wx.StaticText(mypanel_1,id=7869,label=aaj,pos=(data,80))
            CTRL.SetValue("")

            line = str("温馨提示，今日" + weather_dict.get('data').get('ganmao'))
            WXTS = wx.StaticText(mypanel_1, id=222, pos=(40, 30), label=line)
            WXTS.SetForegroundColour('blue')


            #CTRL.AppendText(q)
        FRAME_1.Show()
        FRAME_1.Center()
        aa.MainLoop()



if __name__=="__main__":
   mian()



