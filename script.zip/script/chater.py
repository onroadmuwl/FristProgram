#--encoding:utf-8--
from socket import *
from threading import Thread
import sys
import wx
desip = '10.0.0.131'  #对方IP
desport = '41777'     #对方端口
upsocket = socket(AF_INET, SOCK_DGRAM)#IPV4，UDP
upsocket.bind(('10.0.0.1', 42949))# 自身IP，端口

def frame():
    myapp = wx.App()
    myframe = wx.Frame(None, title="简易聊天", size=(350, 350))
    mypanel = wx.Panel(myframe)
    text = wx.StaticText(mypanel, 2, label="主机", pos=(10, 10))
    global ctrl
    ctrl = wx.TextCtrl(mypanel, 3, size=(300, 200), pos=(30, 30),style=wx.TE_MULTILINE)
    global ctrl_1
    ctrl_1 = wx.TextCtrl(mypanel, 4, size=(210, 50), pos=(30, 240),style=wx.TE_MULTILINE)
    button = wx.Button(mypanel, 5, size=(70, 30), label='发送', pos=(260, 235))
    button_quit = wx.Button(mypanel, 6, size=(70, 30), label='退出主程序', pos=(260, 275))
    button_quit.Bind(wx.EVT_BUTTON,QUIT)
    button.Bind(wx.EVT_BUTTON,send)
    myframe.Show()
    myapp.MainLoop()
def QUIT(event):  #退出
    sys.exit(0)

def recive():
    while True:
        rec_info = upsocket.recvfrom(2048)
        rec_words = str((rec_info[1], rec_info[0].decode("utf8")))
        ctrl.AppendText(rec_words)#接收消息
        ctrl.AppendText('\n')#换行

def send(event):
    send_mess=ctrl_1.GetValue()
    send_word=send_mess.encode('utf-8')
    upsocket.sendto(send_word, (('10.0.0.1', 42949)))  # 使自己发出的消息出现在自己的消息栏里面
    upsocket.sendto(send_word, ('10.0.0.131', 41777))  # 发给对方消息
    ctrl_1.SetValue("")

'''
def main():
    tr = Thread(target=recive)#双线程
    fr = Thread(target=frame)
    tr.start()
    fr.start()
'''