#encoding:utf-8--
import smtplib
from email.mime.text import MIMEText
from email.header import Header
import wx
def FRAME():
    myapp = wx.App()
    FRAME=wx.Frame(title='e-mail',id=2,parent=None,size=(600,600))
    mypanel=wx.Panel(FRAME)
    menubar=wx.MenuBar()
    menu_1=wx.Menu()
    sub=wx.MenuItem(menu_1,id=12,text="设置标题字体")
    txt=wx.MenuItem(menu_1,id=13,text="设置正文字体")
    menu_1.Bind(wx.EVT_MENU,eventmenu)
    menu_1.Append(sub)
    menu_1.Append(txt)
    FRAME.SetMenuBar(menubar)
    menubar.Append(menu_1,title="设置字体")
    text=wx.StaticText(mypanel,id=7,label='主题',pos=(50,20))
    font = wx.Font(15, wx.SCRIPT, wx.NORMAL, wx.BOLD)
    font_1 = wx.Font(20, wx.SCRIPT, wx.ITALIC, wx.BOLD)
    font_2 = wx.Font(15, wx.SCRIPT, wx.ITALIC, wx.BOLD)
    text.SetFont(font)
    global ctrl
    global ctrl_1
    global ctrl_2
    global ctrl_3
    ctrl=wx.TextCtrl(mypanel,id=1,size=(350,40),pos=(50,45))
    text_1=wx.StaticText(mypanel,id=9,label="正文",pos=(50,100))
    ctrl_1= wx.TextCtrl(mypanel, id=11, style=wx.TE_MULTILINE,size=(350, 400), pos=(50,130))
    ctrl_1.SetFont(font_2)
    text_3=wx.StaticText(mypanel,id=100,label='发送方',pos=(410,150))
    text_4 = wx.StaticText(mypanel, id=170, label='接收方', pos=(410, 210))
    ctrl_2 = wx.TextCtrl(mypanel, id=116, size=(160,30), pos=(410, 170))
    ctrl_2.SetValue("muwl182@163.com")
    ctrl_3 = wx.TextCtrl(mypanel, id=118, size=(160,30), pos=(410, 230))
    BUTTON=wx.Button(mypanel,id=999,label='发送',size=(80,40),pos=(440,300))
    BUTTON_1 = wx.Button(mypanel, id=9299, label='退出', size=(80, 40), pos=(440, 360))
    BUTTON.Bind(wx.EVT_BUTTON,send)
    #BUTTON.Bind(wx.EVT_BUTTON,MESSAGE)
    BUTTON_1.Bind(wx.EVT_BUTTON,QUIT)
    FRAME.Show()
    FRAME.Center()
    myapp.MainLoop()

def eventmenu(event):
    ID=event.GetId()
    if ID==12:
        dlg=wx.FontDialog(None,wx.FontData())
        if dlg.ShowModal()==wx.ID_OK:
            data = dlg.GetFontData()
            Font = data.GetChosenFont()
            colour = data.GetColour()
            ctrl.SetFont(Font)
            ctrl.SetForegroundColour(colour)
    elif ID==13:
        dlg=wx.FontDialog(None,wx.FontData())
        if dlg.ShowModal()==wx.ID_OK:
            data=dlg.GetFontData()
            Font=data.GetChosenFont()
            colour=data.GetColour()
            ctrl_1.SetFont(Font)
            ctrl_1.SetForegroundColour(colour)


def send(event):
    sender = ctrl_2.GetValue()
    receiver = ctrl_3.GetValue()
    subject = ctrl.GetValue()
    smtpserver = 'smtp.163.com'
    username = 'muwl182@163.com'
    password = 'muwenlong123'
    test = ctrl_1.GetValue()
    msg = MIMEText(test, 'plain', 'utf-8')
    msg['Subject'] = Header(subject, 'utf-8')
    msg['To'] = receiver
    smtp = smtplib.SMTP(smtpserver, 25)
    smtp.set_debuglevel(1)
    smtp.helo(smtpserver)
    smtp.ehlo(smtpserver)
    smtp.login(username, password)
    smtp.sendmail(sender, receiver, msg.as_string())
    smtp.quit()
    ctrl.SetValue("")
    ctrl_1.SetValue("")
    ctrl_2.SetValue("")
    ctrl_3.SetValue("")
    word=ctrl.GetValue()
    if word=="":
        MESSAGE(event)


def MESSAGE(event):
    ma=wx.MessageDialog(None,"邮件已发送成功","正确",wx.OK|wx.ICON_INFORMATION)
    ma.ShowModal()
    ma.Destroy()
def QUIT(event):
    quit()

'''
if __name__=='__main__':
    FRAME()
'''