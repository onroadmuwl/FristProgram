#encoding:utf-8--
import wx
from threading import Thread
from socket import *
import sys
from script import sendemail
from script import database
from script import weather
from script import chater
def dis(event):
    quit(True)

def email(event):
    sendemail.FRAME()

def data(event):
    database.gui()

def weathers(event):
    weather.mian()

def chaters(event):
    chater.frame()

def choice(event):
    if format(event.GetString())=="水墨画":
        cai(event=True)

    elif format(event.GetString())=="搞笑":
        wu(event=True)

    elif format(event.GetString())=="科幻":
        li(event=True)

    elif format(event.GetString())=="纯色":
        no(event=True)


def cai(event):
    bitmap5 = wx.Image("script\shuimohua.jpg", wx.BITMAP_TYPE_JPEG).ConvertToBitmap()
    BTN = wx.ComboBox(mypanel, -1, choices=list, pos=(500, 295), size=(100, 30))
    btn5 = wx.StaticBitmap(mypanel, -1, bitmap5, pos=(0, 0), size=(680, 350))
    word = wx.StaticText(mypanel, -1, label="高级程序期末作业", pos=(250, 20))
    font = wx.Font(20, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
    word.SetFont(font)
    txt = wx.StaticText(mypanel, -1, pos=(400, 300), label="选择主页面背景")
def wu(event):
    bitmap5 = wx.Image("script\gaoxiao.jpg", wx.BITMAP_TYPE_JPEG).ConvertToBitmap()
    BTN = wx.ComboBox(mypanel, -1, choices=list, pos=(500, 295), size=(100, 30))
    btn5 = wx.StaticBitmap(mypanel, -1, bitmap5, pos=(0, 0), size=(680, 350))
    word = wx.StaticText(mypanel, -1, label="高级程序期末作业", pos=(250, 20))
    font = wx.Font(20, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
    word.SetFont(font)
    txt = wx.StaticText(mypanel, -1, pos=(400, 300), label="选择主页面背景")
def li(event):
    bitmap5 = wx.Image("script\kehuan.jpg", wx.BITMAP_TYPE_JPEG).ConvertToBitmap()
    BTN = wx.ComboBox(mypanel, -1, choices=list, pos=(500, 295), size=(100, 30))
    btn5 = wx.StaticBitmap(mypanel, -1, bitmap5, pos=(0, 0), size=(680, 350))
    word = wx.StaticText(mypanel, -1, label="高级程序期末作业", pos=(250, 20))
    font = wx.Font(20, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
    word.SetFont(font)
    txt = wx.StaticText(mypanel, -1, pos=(400, 300), label="选择主页面背景")
def no(event):
    bitmap5 = wx.Image("script\o.jpg", wx.BITMAP_TYPE_JPEG).ConvertToBitmap()
    BTN = wx.ComboBox(mypanel, -1, choices=list, pos=(500, 295), size=(100, 30))
    btn5 = wx.StaticBitmap(mypanel, -1, bitmap5, pos=(0, 0), size=(680, 350))
    word = wx.StaticText(mypanel, -1, label="高级程序期末作业", pos=(250, 20))
    font = wx.Font(20, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
    word.SetFont(font)
    txt = wx.StaticText(mypanel, -1, pos=(400, 300), label="选择主页面背景")




def program():
    app = wx.App()
    win = wx.Frame(None, -1, title="高级程序设计——PYTHON", size=(700, 400))
    global mypanel
    mypanel = wx.Panel(win)
    menubar = wx.MenuBar()
    menu = wx.Menu()
    btn = menu.Append(-1, "quit")
    menubar.Append(menu, "file")
    menu.AppendSeparator()
    win.SetMenuBar(menubar)
    win.Bind(wx.EVT_MENU,quit,btn)
    word = wx.StaticText(mypanel, -1, label="高级程序期末作业", pos=(250, 20))
    font = wx.Font(20, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
    word.SetFont(font)
    bitmap1 = wx.Image("script\email.jpg", wx.BITMAP_TYPE_JPEG).ConvertToBitmap()
    bitmap2 = wx.Image("script\chat.jpg", wx.BITMAP_TYPE_JPEG).ConvertToBitmap()
    bitmap3 = wx.Image("script\catch.jpg", wx.BITMAP_TYPE_JPEG).ConvertToBitmap()
    bitmap4 = wx.Image("script\database.jpg", wx.BITMAP_TYPE_JPEG).ConvertToBitmap()
    txt = wx.StaticText(mypanel, -1, pos=(400, 300), label="选择主页面背景")
    global list
    list = ["纯色", "水墨画", "搞笑", "科幻"]
    BTN = wx.ComboBox(mypanel, -1, choices=list,value="默认", pos=(500, 295), size=(100, 30))
    btn_1 = wx.BitmapButton(mypanel, -1, bitmap1, pos=(40, 100), size=(120, 120))
    btn_2 = wx.BitmapButton(mypanel, -1, bitmap2, pos=(200, 100), size=(120, 120))
    btn_3 = wx.BitmapButton(mypanel, -1, bitmap3, pos=(360, 100), size=(120, 120))
    btn_4 = wx.BitmapButton(mypanel, -1, bitmap4, pos=(520, 100), size=(120, 120))
    BTN.Bind(wx.EVT_COMBOBOX, choice)
    win.Bind(wx.EVT_MENU, dis, btn)
    btn_1.Bind(wx.EVT_BUTTON, email)
    btn_2.Bind(wx.EVT_BUTTON, chaters)
    btn_3.Bind(wx.EVT_BUTTON, weathers)
    btn_4.Bind(wx.EVT_BUTTON, data)


    win.Show()
    win.Center()
    app.MainLoop()






