#coding:utf-8--
import wx
import pymysql
def frame():
    app=wx.App()
    fra=wx.Frame(None,-1,title="新用户注册",size=(300,200))
    mypanel=wx.Panel(fra)
    sta=wx.StaticText(mypanel,-1,label="请输入用户名：",pos=(10,20))
    sta = wx.StaticText(mypanel, -1, label="请输入密码：", pos=(10, 50))
    sta = wx.StaticText(mypanel, -1, label="请再次输入密码：", pos=(10, 80))
    global ctrl
    global ctrl_1
    global ctrl_2
    ctrl=wx.TextCtrl(mypanel,-1,size=(150,20),pos=(120,20))
    ctrl_1 = wx.TextCtrl(mypanel, -1, size=(150, 20), pos=(120, 45),style=wx.TE_PASSWORD)
    ctrl_2 = wx.TextCtrl(mypanel, -1, size=(150, 20), pos=(120, 75),style=wx.TE_PASSWORD)
    btn=wx.Button(mypanel,-1,label="确定",size=(50,25),pos=(110,120))
    btn.Bind(wx.EVT_BUTTON,write)
    fra.Center()
    fra.Show()
    app.MainLoop()

def write(event):
    name =ctrl.GetValue()
    while True:
        pwd1 =ctrl_1.GetValue()
        pwd2 = ctrl_2.GetValue()
        if pwd1 == pwd2:
            break
    try:
        conn = pymysql.connect(host="127.0.0.1", port=3306, user="muwenlong", passwd="12345678", db="login",
                               charset="utf8")
        cus1 = conn.cursor()
        sql = "insert into users(name,passwd) values(%s,%s)"
        pwd = pwd2
        #print(pwd)
        res = [name, pwd]
        print(res)
        cus1.execute(sql, res)
        conn.commit()
        cus1.close()
        conn.close()
    except Exception as e:
        dlg = wx.MessageDialog(None, "注册出错！", "WRONG", wx.OK | wx.ICON_ERROR)
        dlg.ShowModal()
        dlg.Destroy()
    else:
        dlg=wx.MessageDialog(None,"恭喜您注册成功！","right",wx.OK|wx.ICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()
        ctrl.SetValue("")
        ctrl_1.SetValue("")
        ctrl_2.SetValue("")




