import wx
import pymysql
def frame():
    app=wx.App()
    FRAME=wx.Frame(None,-1,title="删除学生信息",size=(450,150))
    mypanel=wx.Panel(FRAME)
    stat=wx.StaticText(mypanel,-1,label="请输入要删除内容，并选择删除内容对应的属性！",pos=(130,90))
    global CTRL
    CTRL=wx.TextCtrl(mypanel,-1,size=(150,30),pos=(20,30))
    font=wx.Font(15,wx.DECORATIVE,wx.NORMAL,wx.BOLD)
    font_1 = wx.Font(10, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
    CTRL.SetFont(font)
    stat.SetFont(font_1)
    list=['序号','学号','姓名','性别','专业']
    COM=wx.ComboBox(mypanel,-1,choices=list,value="请选择属性",size=(160,40),pos=(210,32))
    COM.Bind(wx.EVT_COMBOBOX,select)
    FRAME.Show()
    FRAME.Center()
    app.MainLoop()

def select(event):
    global content
    global word
    content=format(event.GetString())
    word=CTRL.GetValue()
    dlg=wx.MessageDialog(None,"是否确认删除"+content+"为"+word+"的记录?","确认",wx.YES_NO|wx.ICON_QUESTION)
    if dlg.ShowModal()==wx.ID_YES:
        seacrh()
    dlg.Destroy()

def seacrh():
    try:
        db = pymysql.connect(host="127.0.0.1", user="muwenlong", passwd="12345678", db="学生数据管理系统", charset='utf8')
        cus1 = db.cursor()
        SQL="delete from 学生基本信息表 where 学生基本信息表."+content
        sql = SQL + "=%s" % (word)
        #res = [content, word]
        cus1.execute(sql)
        db.commit()
        cus1.close()
        db.close()
        CTRL.SetValue("")

    except Exception as e:
        dlg = wx.MessageDialog(None, "删除出错，请重试！", "WRONG", wx.OK | wx.ICON_ERROR)
        dlg.ShowModal()
        dlg.Destroy()
